import React from 'react';
import Hyperspeed, { hyperspeedPresets } from './Hyperspeed';
import './SplitScreenPage.css';

const SplitScreenPage = ({ isDarkMode }) => {
    return (
        <div className={`split-screen-container ${isDarkMode ? 'dark' : ''}`}>
            <div className="split-screen-content">
                {/* --- Left Side Content --- */}
                {/* You can put any content you want here */}
                <h1>Welcome Back!</h1>
                <p>This is the left side of the page. You can add your dashboard, welcome message, or any other components here.</p>
                <button>Get Started</button>
            </div>
            <div className="split-screen-animation">
                {/* --- Right Side Animation --- */}
                <Hyperspeed effectOptions={hyperspeedPresets.one} />
                <div className="animation-overlay-text">
                    <h2>RentalWheels</h2>
                    <p>Drive the Future.</p>
                </div>
            </div>
        </div>
    );
};

export default SplitScreenPage;